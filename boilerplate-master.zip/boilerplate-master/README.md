
# Installation

 1. Open terminal and go to your project root directory with this command `cd ~/Path-to-your-project`
 2. Installing `npm` package by writing this command `npm install`
 3. Installing `bower` package by writing this command `bower_install`
 4. Run the gulp to watch your LESS file change by writing this command `gulp` or `gulp watch-start`
 5. Happy coding every body

 

# Frontend Tools:

1. [Bower](http://bower.io)
2. [Gulp](https://gulpjs.com/)


# Frontend Depedency List:

1. [Bootstrap ver.3.4.1](http://getbootstrap.com)
2. [jQuery](http://jquery.com)
